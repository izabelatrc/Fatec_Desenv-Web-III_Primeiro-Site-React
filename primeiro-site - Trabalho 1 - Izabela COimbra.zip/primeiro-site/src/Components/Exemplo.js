function Exemplo(){
    return(
        <div>
        <h3>Estou no exemplo</h3>
        </div>
    )
}

export default Exemplo;


